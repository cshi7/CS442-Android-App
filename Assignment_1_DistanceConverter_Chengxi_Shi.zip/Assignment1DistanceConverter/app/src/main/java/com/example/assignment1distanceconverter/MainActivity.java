package com.example.assignment1distanceconverter;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.view.View;


import java.text.DecimalFormat;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private TextView HistoryView;
    private TextView actionDisplay;
    private TextView actionDisplay2;
    private TextView textView6;
    private TextView textView5;
    private TextView tmp;
    private int flag = 1;
    private String recordH = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //radio button
        actionDisplay = findViewById(R.id.actionDisplay);
        actionDisplay2 = findViewById(R.id.actionDisplay2);
        textView6 = findViewById(R.id.textView6);
        textView5 = findViewById(R.id.textView5);
        tmp = (EditText)findViewById(R.id.editText);

        HistoryView = findViewById(R.id.textView5);
        HistoryView.setMovementMethod(new ScrollingMovementMethod());


    }

    /*public void addText(view v){
        String value = textView1.getText().toString();
        value =  "Time: " + new Date() + "\n" + value;
        textView.setText("Time" + new Date());
    }*/

    /*public void clearText(){
        textView.setText("");
    }*/

    //check the button,if button 1 is on, textview 1 and 2 change to mile to kilometers; else turn mode from kilo to mile
    public void radioClicked(View v) {
        String selectionText = ((RadioButton) v).getText().toString();
        if (selectionText.equals("Miles to Kilometers")){
            actionDisplay.setText(String.format("Miles value: "));
            actionDisplay2.setText(String.format("Kilometers value: "));
            flag = 1;
        }
        else if(selectionText.equals("Kilometers to Miles")){
            actionDisplay.setText(String.format("Kilometers value: "));
            actionDisplay2.setText(String.format("Miles value: "));
            flag = 2;
        }
        else{
            actionDisplay.setText(String.format("Something wrong"));
            actionDisplay2.setText(String.format("Something wrong"));
            flag = 0;
        }
    }

    public void convertFunction(View v){
        /*String trash = tmp.getText().toString();
        textView6.setText(String.format(trash));*/

        double inputNum = Double.valueOf(tmp.getText().toString()).doubleValue();
        double midnum = 0.0;

        if (flag == 1){
            //use midnumber to record the original kilo or mile
            midnum = inputNum;
            //input to changed value
            inputNum = inputNum * 1.60934;
            //update recording for history
            recordH = "Mi to Km: " + String.format("%.1f", midnum) + " ==> " + String.format("%.1f", inputNum) + "\n" + recordH;

            textView6.setText(String.format("%.1f", inputNum));
            textView5.setText(String.format(recordH));

        }
        else if(flag == 2){
            midnum = inputNum;
            inputNum = inputNum * 0.621371;
            recordH = "Km to Mi: " + String.format("%.1f", midnum) + " ==> " + String.format("%.1f", inputNum) + "\n" + recordH;
            textView6.setText(String.format("%.1f",inputNum));
            textView5.setText(String.format(recordH));
        }
        else{
            textView6.setText(String.format("invalid"));
        }
    }

    public void clearFunction(View v){
        recordH = "";
        textView5.setText("");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState){
        outState.putString("tv6", textView6.getText().toString());
        outState.putString("tv5", textView5.getText().toString());
        outState.putString("et", tmp.getText().toString());
        outState.putString("history", recordH);
        outState.putString("ad1", actionDisplay.getText().toString());
        outState.putString("ad2", actionDisplay2.getText().toString());
        outState.putInt("flagnum", flag);

        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        // Call super first
        super.onRestoreInstanceState(savedInstanceState);

        recordH = savedInstanceState.getString("history");
        flag = savedInstanceState.getInt("flagnum");
        textView5.setText(savedInstanceState.getString("tv5"));
        textView6.setText(savedInstanceState.getString("tv6"));
        tmp.setText(savedInstanceState.getString("et"));
        actionDisplay.setText(savedInstanceState.getString("ad1"));
        actionDisplay2.setText(savedInstanceState.getString("ad2"));
    }
}
