package com.example.assign2multinotes;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Objects;
import java.util.TimeZone;

public class EditActivity extends AppCompatActivity{
    private EditText noteName;
    private EditText noteContent;
    private Note t_note;
    private int passNoteFlag = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        noteName = findViewById(R.id.editnoteName);
        noteContent = findViewById(R.id.editnoteContent);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //if it goes from onclick function, it should set the original note
        //if it goes from the edit button, it should create a new note with blank title and content
        Intent intent = getIntent();
        if (intent.hasExtra("existNote")) {
            passNoteFlag = 1;
            String[] text = (intent.getStringExtra("existNote")).split(",");
            noteName.setText(text[0]);
            noteContent.setText(text[3]);
        }
        setTitle();

    }

    //add the save menu button
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.action_menu_edit, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            //want to save the note
            case R.id.saveButton:
                //Toast.makeText(this, "Now saving", Toast.LENGTH_SHORT).show();
                doneClicked(noteName);
                return true;
            default:
                onBackPressed();
                return true;
                //return super.onOptionsItemSelected(item);
        }
    }

    public void doneClicked(View v){
        //create a data to save the things that we want to pass back to main activity
        Intent data = new Intent();
        //do save function
        //check if it do have title, if it is not empty, go on; if not, toast a message and return
        if(!(noteName.getText().toString()).isEmpty()){
            if(passNoteFlag == 1){
                //Toast.makeText(this,"Now in edit exist note!",Toast.LENGTH_SHORT).show();
                if(noteContent.getText().toString().isEmpty()){
                    noteContent.setText(" ");
                }
                data.putExtra("Note_Name", noteName.getText().toString());
                data.putExtra("Note_Content", noteContent.getText().toString());
                //data.putExtra("Change_Date",getCurrentDate());
                //data.putExtra("Note_ID",trash);
                data.putExtra("existNotePos", getIntent().getStringExtra("existNotePos"));
                data.putExtra("New_Note","");
                setResult(RESULT_OK, data);
                finish();
            }
            else{
                Note note = new Note();
                if(noteContent.getText().toString().isEmpty()){
                    noteContent.setText(" ");
                }
                note.setNewInfo(noteName.getText().toString(),noteContent.getText().toString());
                data.putExtra("New_Note",note.toString());
                setResult(RESULT_OK, data);
                finish();
            }
        }
        else{
            Toast.makeText(this,"You should have a title at least!", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        //check if it is a passed note or not, if it is a pass note
        //Toast.makeText(this,String.valueOf(passNoteFlag),Toast.LENGTH_SHORT).show();
        if(passNoteFlag == 1){
            Intent intent = getIntent();
            String[] trash = intent.getStringExtra("existNote").split(",");
            if((trash[0].compareTo(noteName.getText().toString()) == 0)&&(trash[3].compareTo(noteContent.getText().toString()))==0){
                finish();
            }
            else{
                if(dialogBox()){
                    return;
                };
            }
        }
        else{
            //check note name and note content, if both empty, directly quit; if one of it not empty, give the dialog box
            if((noteName.getText().toString().isEmpty())&&(noteContent.getText().toString().isEmpty())){
                finish();
            }
            else{
                if(dialogBox()){
                    return;
                };
            }
        }
        //super.onBackPressed();
    }

    public Boolean dialogBox(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Do you want to quit edit note without saving?");
        builder.setCancelable(true);

        builder.setPositiveButton(
                "Save and quit",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        doneClicked(noteName);
                    }
                }
        );
        builder.setNegativeButton(
                "Just quit",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                }
        );
        AlertDialog alert = builder.create();
        alert.show();
        return true;
    }

    public String getCurrentDate(){
        java.util.Date currentTime = Calendar.getInstance().getTime();
        //Chicago time zone
        TimeZone.setDefault(TimeZone.getTimeZone("GMT-6"));
        @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat("EEE/MMM/d/yyyy HH:mm:ss");

        //Toast.makeText(this,sdf.format(currentTime), Toast.LENGTH_SHORT).show();
        return sdf.format(currentTime);
    }

    public void setTitle(){
        setTitle("MultiNotes");
    }



}

