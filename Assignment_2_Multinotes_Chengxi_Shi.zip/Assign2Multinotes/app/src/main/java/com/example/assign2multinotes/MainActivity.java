package com.example.assign2multinotes;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.Context;

import android.os.Bundle;
import android.os.SystemClock;

import android.view.Menu;
import android.view.MenuItem;

import android.widget.TextView;
import android.widget.Toast;
import android.widget.EditText;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.util.JsonWriter;
import android.util.Log;

import java.text.DateFormat;
import java.text.SimpleDateFormat;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Calendar;
import java.util.TimeZone;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringWriter;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener {


    private final List<Note> noteList = new ArrayList<>();
    private RecyclerView recyclerView;  // Layout's recyclerview
    private TextView textView;
    //private SharedPreference prefs;
    private static final int EDIT_REQUEST_CODE = 11111;

    private static final String TAG = "MainActivity";
    private int pos;
    private int add_Flag = 0;
    private Note t_note;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        recyclerView = findViewById(R.id.recycler);

        NoteAdapter nAdapter = new NoteAdapter(noteList, this);
        recyclerView.setAdapter(nAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        String saveFile = loadFile();
        if(saveFile.isEmpty()){
            for (int i = 0; i < 3; i++) {
                noteList.add(new Note());
            }
        }


        setTitle();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.action_menu, menu);
        return true;
    }

    //JSON functions
    //////////////////////////////////////////////////////////////////////
    @Override
    protected void onResume() {
        String saveFile = loadFile();
        if(!(saveFile.isEmpty())){
            //reset the recycler
            //Toast.makeText(this,saveFile,Toast.LENGTH_SHORT).show();

            recyclerView = findViewById(R.id.recycler);
            NoteAdapter nAdapter = new NoteAdapter(noteList, this);
            recyclerView.setAdapter(nAdapter);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));

            //toString method for arraylist use [] to build the string[], which I want to delete[ from first item and ] from last item
            String[] temp = saveFile.split(",");
            temp[0] = temp[0].substring(1,temp[0].length());
            int t_length = temp.length;
            temp[t_length-1] = temp[t_length-1].substring(0,temp[t_length-1].length()-1);

            noteList.removeAll(noteList);

            for(int a = 0;a<t_length;a+=4){
                //it do put space for the following note except first note, which i want to delete the space
                temp[a] = temp[a].replaceAll("\\s","");
                noteList.add(new Note(temp[a],Long.parseLong(temp[a+1]),temp[a+2],temp[a+3]));
            }

            setTitle();
        }
        super.onResume();
    }

    private String loadFile(){
        String saveFile = "";
        try {
            InputStream is = getApplicationContext().
                    openFileInput("Note.json");

            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));

            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }

            JSONObject jsonObject = new JSONObject(sb.toString());
            String notes = jsonObject.getString("notes");
            saveFile = notes;

        } catch (FileNotFoundException e) {
            Toast.makeText(this, "Don't have Note.json!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return saveFile;
    }

    @Override
    protected void onPause() {
        String notePass = noteList.toString();
        saveNote(notePass);
        super.onPause();
    }

    private void saveNote(String notePass){
        try {
            FileOutputStream fos = getApplicationContext(). openFileOutput(("Note.json"), Context.MODE_PRIVATE);

            JsonWriter writer = new JsonWriter(new OutputStreamWriter(fos, "UTF-8"));
            writer.setIndent("");
            writer.beginObject();
            writer.name("notes").value(notePass);
            writer.endObject();
            writer.close();
        }
        catch (Exception e) {
            e.getStackTrace();
        }
    }


    //////////////////////////////////////////////////////////////////////
    //finish JSON function
    public void setTitle(){
        setTitle("MultiNotes" + "(" + noteList.size() + ")");
    }


    //////////////////////////////////////////////////////////////////////
    //Menu activity
    @Override
    public void onClick(View v) {
        pos = recyclerView.getChildLayoutPosition(v);
        t_note = noteList.get(pos);

        Intent intent = new Intent(MainActivity.this, EditActivity.class);
        intent.putExtra("existNote",t_note.toString() );
        intent.putExtra("existNotePos", String.valueOf(pos));
        startActivityForResult(intent, EDIT_REQUEST_CODE);

        //Toast.makeText(this,String.valueOf(pos),Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onLongClick(View v) {
        pos = recyclerView.getChildLayoutPosition(v);
        t_note = noteList.get(pos);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Do you want to delete this note?");
        builder.setCancelable(true);
        builder.setPositiveButton(
                "Yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //delete the note
                        //re-sort the note by time
                        //re-show the recycler review
                        noteList.remove(t_note);
                        saveNote(noteList.toString());
                        onResume();
                    }
                }
        ).setNegativeButton(
                "No",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                }
        );
        AlertDialog alert = builder.create();
        alert.show();
        //Toast.makeText(this,t_note.toString(),Toast.LENGTH_SHORT).show();
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.aboutOpt:
                openAboutActivity(textView);
                return true;
            case R.id.editOpt:
                openEditActivity(textView);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void openAboutActivity(View v) {
        //Toast.makeText(this,"Now in edit activity", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(MainActivity.this, AboutActivity.class);
        intent.putExtra(Intent.EXTRA_TEXT, MainActivity.class.getSimpleName());
        startActivity(intent);
    }

    public void openEditActivity(View v) {
        //Toast.makeText(this,"Now in edit activity", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(MainActivity.this, EditActivity.class);
        intent.putExtra(Intent.EXTRA_TEXT, MainActivity.class.getSimpleName());
        startActivityForResult(intent, EDIT_REQUEST_CODE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == EDIT_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                String noteInfo = data.getStringExtra("New_Note");
                //if New Note is empty or null, which means it is a already have notes
                if(noteInfo.isEmpty()||noteInfo == null){
                    pos = Integer.parseInt(data.getStringExtra("existNotePos"));
                    noteList.get(pos).setNewInfo(data.getStringExtra("Note_Name"),data.getStringExtra("Note_Content"));
                    t_note = noteList.get(pos);
                    noteList.add(0,t_note);
                    noteList.remove(pos+1);
                    saveNote(noteList.toString());
                    onResume();
                }
                else{
                    String[] temp_note = noteInfo.split(",");
                    noteList.add(0,new Note(temp_note[0],Long.parseLong(temp_note[1]),temp_note[2],temp_note[3]));
                    saveNote(noteList.toString());
                    onResume();
                }
            }
        }
    }

    @Override
    public void onBackPressed() {
        //Toast.makeText(this,"You pressed back, now exit!",Toast.LENGTH_SHORT).show();
        super.onBackPressed();
    }

}
