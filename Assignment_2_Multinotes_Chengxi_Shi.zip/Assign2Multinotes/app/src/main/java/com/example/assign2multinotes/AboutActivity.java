package com.example.assign2multinotes;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class AboutActivity extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        TextView textView = findViewById(R.id.appName);
        textView.setText(String.format("Application name: MultiNotes"));
        textView = findViewById(R.id.date);
        textView.setText(String.format("Date: 02/17/2020"));
        textView = findViewById(R.id.author);
        textView.setText(String.format("Author: Chengxi Shi"));
        textView = findViewById(R.id.versionNumb);
        textView.setText(String.format("Version: 1.0"));


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
