package com.example.assign2multinotes;

import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

public class MyViewHolder extends RecyclerView.ViewHolder{

    public TextView noteName;
    //TextView msgId;
    TextView noteContent;
    TextView noteDate;

    MyViewHolder(View view) {
        super(view);
        noteName = view.findViewById(R.id.editnoteName);
        noteContent = view.findViewById(R.id.editnoteContent);
        noteDate = view.findViewById(R.id.noteDate);
    }
}
