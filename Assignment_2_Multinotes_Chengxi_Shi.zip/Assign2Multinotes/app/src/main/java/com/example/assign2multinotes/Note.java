package com.example.assign2multinotes;

import android.annotation.SuppressLint;

import androidx.annotation.NonNull;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;

public class Note {
    private String noteName;
    private long noteID;
    private String lastSaveDate;
    private String noteContent;

    private static int ctr = 1;
    private final long baseID = 10000000;

    Note(){
        this.noteName =  "" + ctr;
        this.noteID = baseID + ctr;
        this.lastSaveDate = getCurrentDate();
        this.noteContent = "" + ctr;
        ctr++;
    }
    Note(String passName, long passID, String passDate, String passContent){
        this.noteName = passName;
        this.noteID = passID;
        this.lastSaveDate = passDate;
        this.noteContent = passContent;
        ctr++;
    }

    public String getCurrentDate(){
        java.util.Date currentTime = Calendar.getInstance().getTime();
        //Chicago time zone
        TimeZone.setDefault(TimeZone.getTimeZone("GMT-6"));
        @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat("EEE/MMM/d/yyyy HH:mm:ss");

        //Toast.makeText(this,sdf.format(currentTime), Toast.LENGTH_SHORT).show();
        return sdf.format(currentTime);
    }

    public void setNewInfo(String a, String b){
        this.noteName = a;
        this.noteContent = b;
        this.lastSaveDate = getCurrentDate();
    }

    public String getNoteName(){
        return this.noteName;
    }

    public long getNoteID(){
        return this.noteID;
    }

    public String getNoteContent(){
        return this.noteContent;
    }

    public String getLastSaveDate(){
        return this.lastSaveDate;
    }

    @NonNull
    @Override
    public String toString() {
        return noteName + "," + noteID + "," + lastSaveDate+ "," + noteContent;
    }
}
