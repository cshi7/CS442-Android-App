package com.example.assignment3_stockwatch;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;
import java.util.Locale;

public class StockAdapter extends RecyclerView.Adapter<MyViewHolder>{
    private static final String TAG = "StockAdapter";
    private List<Stock> stockList;
    private MainActivity mainAct;

    StockAdapter(List<Stock> stkList, MainActivity ma){
        this.stockList = stkList;
        mainAct = ma;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull final ViewGroup parent, int viewType) {
        Log.d(TAG, "onCreateViewHolder: MAKING NEW");
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.stock_list_row, parent, false);

        itemView.setOnClickListener(mainAct);
        itemView.setOnLongClickListener(mainAct);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Stock stock = stockList.get(position);
        if(stock.getPriceChange()>=0){
            holder.stockSymbol.setText(stock.getStockSymbol());
            holder.stockSymbol.setTextColor(Color.GREEN);
            holder.companyName.setText(stock.getCompanyName());
            holder.companyName.setTextColor(Color.GREEN);
            holder.price.setText(Double.toString(stock.getPrice()));
            holder.price.setTextColor(Color.GREEN);
            String temp = "▲" + Double.toString(stock.getPriceChange());
            holder.priceChange.setText(temp);
            holder.priceChange.setTextColor(Color.GREEN);
            temp = "(" + Double.toString(stock.getChangePercent()) + "）";
            holder.changePercent.setText(temp);
            holder.changePercent.setTextColor(Color.GREEN);
        }
        else{
            holder.stockSymbol.setText(stock.getStockSymbol());
            holder.stockSymbol.setTextColor(Color.RED);
            holder.companyName.setText(stock.getCompanyName());
            holder.companyName.setTextColor(Color.RED);
            holder.price.setText(Double.toString(stock.getPrice()));
            holder.price.setTextColor(Color.RED);
            String temp = "▼" + Double.toString(stock.getPriceChange());
            holder.priceChange.setText(temp);
            holder.priceChange.setTextColor(Color.RED);
            temp = "(" + Double.toString(stock.getChangePercent()) + "）";
            holder.changePercent.setText(temp);
            holder.changePercent.setTextColor(Color.RED);
        }
    }

    @Override
    public int getItemCount() {
        return stockList.size();
    }
}
