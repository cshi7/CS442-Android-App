package com.example.assignment3_stockwatch;

import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class NameDownloader extends AsyncTask<String, Void, HashMap>{
    private static final String TAG = "NameDownloader";
    private MainActivity mainActivity;

    private static final String stockURL = "https://api.iextrading.com/1.0/ref-data/symbols";
    private static int counter = 0;
    private HashMap<String,String> stockMap = new HashMap<>();

    ArrayList<Stock> stockList = new ArrayList<>();

    NameDownloader(MainActivity ma) {
        mainActivity = ma;
    }

    @Override
    protected HashMap doInBackground(String... strings) {
        Uri.Builder buildURL = Uri.parse(stockURL).buildUpon();
        String urlToUse = buildURL.build().toString();
        StringBuilder sb = new StringBuilder();

        try{
            URL url = new URL(urlToUse);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.connect();

            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK)
                return null;

            InputStream is = connection.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));

            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }

        } catch (Exception e){
            return null;
        }
        //open the json function
        return parseJSON(sb.toString());
    }

    @Override
    protected void onPostExecute(HashMap hashMap) {
        mainActivity.getNameDownloaderHM(hashMap);
    }

    private HashMap parseJSON(String s){
        try{
            JSONArray jObjMain = new JSONArray(s);
            for(int i=0;i<jObjMain.length();i++){
                JSONObject stock = (JSONObject)jObjMain.get(i);
                String stockSymbol = stock.getString("symbol");
                String companyName = stock.getString("name");
                stockMap.put(stockSymbol,companyName);
            }
            //JSONArray stocks = jObjMain.get(0);
            return stockMap;
        } catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

   /*@Override
    protected void onPostExecute(Stock stock) {
        mainActivity.doTest(stock);
    }*/
}
