package com.example.assignment3_stockwatch;

import androidx.annotation.NonNull;

public class Stock {
    private String stockSymbol;
    private String companyName;
    private double price;
    private double priceChange;
    private double changePercent;

    private static int ctr = 1;

    Stock(){
        this.stockSymbol = "" + ctr;
        this.companyName = "" + ctr;
        this.price = ctr;
        this.priceChange = ctr;
        this.changePercent = ctr;
        ctr++;
    }
    Stock(String ss, String cn, String p, String pc, String cp){
        this.stockSymbol = ss;
        this.companyName = cn;
        this.price = Double.parseDouble(p);
        this.priceChange = Double.parseDouble(pc);
        this.changePercent = Double.parseDouble(cp);
        ctr++;
    }

    public String getStockSymbol(){
        return stockSymbol;
    }

    public String getCompanyName(){
        return companyName;
    }

    public double getPrice(){
        return price;
    }

    public double getPriceChange(){
        return priceChange;
    }

    public double getChangePercent(){
        return changePercent;
    }

    @NonNull
    @Override
    public String toString() {
        return stockSymbol + "," + companyName + "," + price + "," + priceChange + "," + changePercent;
    }
}
