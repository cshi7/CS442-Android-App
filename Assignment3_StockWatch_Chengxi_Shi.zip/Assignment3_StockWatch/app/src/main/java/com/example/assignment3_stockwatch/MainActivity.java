package com.example.assignment3_stockwatch;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.arch.core.executor.DefaultTaskExecutor;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import java.util.Locale;

public class MainActivity extends AppCompatActivity
        implements View.OnClickListener, View.OnLongClickListener{

    private TextView textView;
    private SwipeRefreshLayout swiper;
    private final String TAG = "MainActivity";

    private List<Stock> stockList = new ArrayList<>();
    private RecyclerView recyclerView;
    private StockAdapter mAdapter;

    public DatabaseHandler databaseHandler;

    private static final int ADD_CODE = 1;

    private static final String marketwatch = "https://www.marketwatch.com/investing/stock/";
    private String temp = "";
    private int selectIndex;
    private boolean flag;

    private HashMap<String,String> NameDownloaderHM = new HashMap<>();
    private HashMap<String,String> compareMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        swiper = findViewById(R.id.swiper);

        recyclerView = findViewById(R.id.recycler);

        mAdapter = new StockAdapter(stockList, this);

        recyclerView.setAdapter(mAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        swiper.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                doRefresh();
            }
        });
        databaseHandler = new DatabaseHandler(this);

        //based on the net connection to do initialize NameDownloader
        if(doNetCheck()){
            initDB();
        }
    }

    @Override
    protected void onResume() {
        databaseHandler.dumpDbToLog();
        ArrayList<Stock> list = databaseHandler.loadStocks();
        //database not empty and no network, which we want to set all the things in the database to 0(for price, price change and change percent)
        if(!list.isEmpty()&&!doNetCheck()){
            for(int i = 0;i<stockList.size();i++){
                Stock stock = stockList.get(i);
                databaseHandler.updateStock(new Stock(stock.getStockSymbol(),stock.getCompanyName(),"0","0","0"));
            }
            list = databaseHandler.loadStocks();
            stockList.clear();
            stockList.addAll(list);
        }
        else{
            stockList.clear();
            stockList.addAll(list);
            updateStock();
        }
        sequenceSort();
        mAdapter.notifyDataSetChanged();
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        databaseHandler.shutDown();
        super.onDestroy();
    }

    //refresh function for swipe
    private void doRefresh(){
        if(doNetCheck()){
            //Create a new list to contain all stock symbol
            //sequenceSort();

            swiper.setRefreshing(false);
            onResume();
            //Toast.makeText(this,"Connected",Toast.LENGTH_SHORT).show();
        }
        else{
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("No Network Connection");
            builder.setMessage("Stocks Cannot Be Added Without A Network Connection");
            builder.show();

            ArrayList<Stock> list = databaseHandler.loadStocks();
            //database not empty and no network, which we want to set all the things in the database to 0(for price, price change and change percent)
            if(!list.isEmpty()&&!doNetCheck()){
                for(int i = 0;i<stockList.size();i++){
                    Stock stock = stockList.get(i);
                    databaseHandler.updateStock(new Stock(stock.getStockSymbol(),stock.getCompanyName(),"0","0","0"));
                }
                list = databaseHandler.loadStocks();
                stockList.clear();
                stockList.addAll(list);
            }
            sequenceSort();
            mAdapter.notifyDataSetChanged();
            swiper.setRefreshing(false);
        }
        //Toast.makeText(this, "List content shuffled", Toast.LENGTH_SHORT).show();
    }

    //network checking, for airplane mode
    private boolean doNetCheck(){
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) {
            Toast.makeText(this, "Cannot access ConnectivityManager", Toast.LENGTH_SHORT).show();
            return false;
        }
        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        if (netInfo != null && netInfo.isConnected()) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void onClick(View v) {
        //go to the stock website

        if(doNetCheck()){
            int pos = recyclerView.getChildLayoutPosition(v);
            final Stock stock = stockList.get(pos);
            //create url want to view
            String stockSymbol = stock.getStockSymbol();
            String gotoURL = marketwatch + stockSymbol;
            //go to the url by the browser
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse(gotoURL));
            startActivity(i);
        }
        else{
            Toast.makeText(this,"No Network!", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public boolean onLongClick(View v) {
        //delete the stock
        int pos = recyclerView.getChildLayoutPosition(v);
        final Stock stock = stockList.get(pos);
        String trash = "";

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Do you want to delete this stock?");
        builder.setCancelable(true);
        builder.setPositiveButton(
                "Yes",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //delete the note
                        stockList.remove(stock);
                        databaseHandler.deleteStock(stock.getStockSymbol());
                        onResume();
                    }
                }
        ).setNegativeButton(
                "No",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                }
        );
        AlertDialog alert = builder.create();
        alert.show();

        //Toast.makeText(this, stock.getStockSymbol(), Toast.LENGTH_SHORT).show();
        return false;
    }

    //show out the menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.action_menu, menu);
        return true;
    }

    //test for add a new stock
    public void addNewStock(){
        //avoid use airplane mode open the app without initDB
        if(NameDownloaderHM.isEmpty()){
            initDB();
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Stock Selection");
        builder.setMessage("Please enter a Stock Symbol");
        // Set up the input
        final EditText input = new EditText(this);
        // Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
        input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        builder.setView(input);

        // Set up the buttons
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
               public void onClick(DialogInterface dialog, int which) {
                temp = input.getText().toString();
                buildNewSelectionDialog(temp);
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.show();
    }

    //function for menu addStock button
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.addNewStock:
                if(doNetCheck()){
                    addNewStock();
                    recyclerView.setAdapter(mAdapter);
                    return true;
                }
                else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("No Network Connection");
                    builder.setMessage("Stocks Cannot Be Added Without A Network Connection");
                    builder.show();
                }

        }
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Stock stock = null;
        if (data.hasExtra("STOCKSYMBOL")) {
            stock = (Stock) data.getSerializableExtra("STOCKSYMBOL");
        }

        if (stock == null) {
            Toast.makeText(this, "Country data not found in extras", Toast.LENGTH_SHORT).show();
            return;
        }

        switch (requestCode) {
            case ADD_CODE:
                databaseHandler.addStock(stock);
                break;
        }
    }

    public void initDB(){
        new NameDownloader(this).execute("");
    }

    public void getNameDownloaderHM(HashMap hashMap){
        Iterator nameDIterator = hashMap.keySet().iterator();
        while (nameDIterator.hasNext()){
            String key = (String) nameDIterator.next();
            String value = (String) hashMap.get(key);
            NameDownloaderHM.put(key,value);
        }
        //Log.d(TAG, "getNameDownloaderHM: " + "finish");
    }

    public void buildNewSelectionDialog(String s){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        
        Iterator nameDIterator = NameDownloaderHM.keySet().iterator();
        List<String> selectionList = new ArrayList<>();

        compareMap.clear();

        while (nameDIterator.hasNext()){
            String key = (String) nameDIterator.next();
            String value = NameDownloaderHM.get(key);
            if(key == s||key.contains(s)||value.contains(s)){
                if(!key.isEmpty()&&!value.isEmpty()){
                    compareMap.put(key,value);
                    selectionList.add(key + " - " + value);
                }
            }
        }
        Collections.sort(selectionList,null);
        final String[] selectionArray = new String[selectionList.size()];
        for (int i =0; i < selectionList.size(); i++)
            selectionArray[i] = selectionList.get(i);


        //Log.d(TAG, "buildNewSelectionDialog: " + "in build dialog func");

        //if searching symbol not empty
        if(!compareMap.isEmpty()){
            nameDIterator = compareMap.keySet().iterator();
            if(compareMap.size() == 1){
                String symbol = (String) nameDIterator.next();
                doAsyncSD(symbol);
            }
            else{
                builder.setTitle("Make A Selection");
                builder.setCancelable(true);
                builder.setItems(selectionArray, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        selectIndex = which;
                        String[] temp = selectionArray[which].split("-");
                        String temp1 = temp[0].replace(" ","");
                        doAsyncSD(temp1);
                    }
                });
                builder.setPositiveButton("NEVERMIND", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                builder.show();
            }
        }
        else{
            String trash = "Symbol Not Found: " + s;
            builder.setTitle(trash);
            builder.setMessage("Data for stock symbol");
            builder.show();
        }
    }

    public void doAsyncSD(String s){
        new StockDownloader(this).execute(s);
    }

    public void doADDStock(Stock stock){
        //redundancy check
        if (stock == null) {
            return;
        }

        flag = false;
        for(int i = 0;i<stockList.size();i++){
            if(stockList.get(i).getStockSymbol().compareTo(stock.getStockSymbol()) == 0 ){
                flag = true;
            }
        }

        if(flag){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Duplicate Stock");
            String passMessage = "Stock Symbol " + stock.getStockSymbol() + " is already displayed";
            builder.setMessage(passMessage);
            builder.show();
            return;
        }
        //do add
        stockList.add(stock);
        databaseHandler.addStock(stock);
        sequenceSort();
        mAdapter.notifyDataSetChanged();
    }

    public void sequenceSort(){
        List<String> symbolList = new ArrayList<>();
        for(int i =0;i<stockList.size();i++){
            symbolList.add(stockList.get(i).getStockSymbol());
        }
        //sort the symbol by ascending alphabet sequence
        Collections.sort(symbolList,null);
        //sort the stockList
        for(int i = 0;i<symbolList.size();i++){
            //if the first object is not the things we want to find; else i++
            if(stockList.get(i).getStockSymbol().compareTo(symbolList.get(i)) != 0){
                for(int j = 1;j<symbolList.size();j++){
                    //if the inner loop find the things we want, do sequence exchange; else j++
                    if(stockList.get(j).getStockSymbol().compareTo(symbolList.get(i)) == 0){
                        Stock tstock = stockList.get(j);
                        stockList.add(i,tstock);
                        stockList.remove(j+1);
                        break;
                    }
                }
            }
        }
        mAdapter.notifyDataSetChanged();
        return;
    }

    public void updateStock(){
        for(int i = 0;i<stockList.size();i++){
            Stock tstock = stockList.get(i);
            new StockDownloader(this).execute(tstock.getStockSymbol(),tstock.getCompanyName(),String.valueOf(tstock.getPrice()),String.valueOf(tstock.getPriceChange()),String.valueOf(tstock.getChangePercent()));
        }
    }

}
