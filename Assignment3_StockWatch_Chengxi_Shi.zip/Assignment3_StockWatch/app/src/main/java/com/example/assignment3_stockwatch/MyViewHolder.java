package com.example.assignment3_stockwatch;

import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

public class MyViewHolder extends RecyclerView.ViewHolder{
    public TextView stockSymbol;
    TextView companyName;
    TextView price;
    TextView priceChange;
    TextView changePercent;

    MyViewHolder(View view){
        super(view);
        stockSymbol = view.findViewById(R.id.stockSymbol);
        companyName = view.findViewById(R.id.companyName);
        price = view.findViewById(R.id.price);
        priceChange = view.findViewById(R.id.priceChange);
        changePercent = view.findViewById(R.id.changePercent);
    }

}
