package com.example.assignment3_stockwatch;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class DatabaseHandler extends SQLiteOpenHelper{
    private static final String TAG = "DatabaseHandler";
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "StockAppDB";
    private static final String TABLE_NAME = "StockWatchTable";

    ///DB Columns
    private static final String STOCKSYMBOL = "StockSymbol";
    private static final String COMPANYNAME = "CompanyName";
    private static final String PRICE = "Price";
    private static final String PRICECHANGE = "PriceChange";
    private static final String CHANGEPERCENT = "ChangePercent";

    // DB Table Create Code
    private static final String SQL_CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    STOCKSYMBOL + " TEXT not null unique," +
                    COMPANYNAME + " TEXT not null unique," +
                    PRICE + " DOUBLE not null, " +
                    PRICECHANGE + " DOUBLE not null, " +
                    CHANGEPERCENT + " DOUBLE not null)";

    private SQLiteDatabase database;

    DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        database = getWritableDatabase(); // Inherited from SQLiteOpenHelper
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
    ArrayList<Stock> loadStocks(){
        ArrayList<Stock> stocks = new ArrayList<>();

        Cursor cursor = database.query(
                TABLE_NAME,
                new String[]{STOCKSYMBOL, COMPANYNAME, PRICE, PRICECHANGE, CHANGEPERCENT},
                null,
                null,
                null,
                null,
                null
        );
        if (cursor!=null){
            cursor.moveToFirst();

            for (int i = 0; i < cursor.getCount(); i++) {
                String stockSymbol = cursor.getString(0);
                String companyName = cursor.getString(1);
                double price = cursor.getDouble(2);
                double priceChange = cursor.getDouble(3);
                double changePercent = cursor.getDouble(4);
                Stock s = new Stock(stockSymbol, companyName, String.valueOf(price), String.valueOf(priceChange), String.valueOf(changePercent));
                stocks.add(s);
                cursor.moveToNext();
            }
            cursor.close();
        }
        return stocks;
    }

    void addStock(Stock stock){
        ContentValues values = new ContentValues();

        values.put(STOCKSYMBOL, stock.getStockSymbol());
        values.put(COMPANYNAME, stock.getCompanyName());
        values.put(PRICE, stock.getPrice());
        values.put(PRICECHANGE, stock.getPriceChange());
        values.put(CHANGEPERCENT, stock.getChangePercent());

        long key = database.insert(TABLE_NAME, null, values);
    }

    void updateStock(Stock stock) {
        ContentValues values = new ContentValues();

        values.put(STOCKSYMBOL, stock.getStockSymbol());
        values.put(COMPANYNAME, stock.getCompanyName());
        values.put(PRICE, stock.getPrice());
        values.put(PRICECHANGE, stock.getPriceChange());
        values.put(CHANGEPERCENT, stock.getChangePercent());

        database.update("StockWatchTable",values,STOCKSYMBOL + " = ?",new String[]{stock.getStockSymbol()});
        //long numRows = database.update(String.valueOf(3), values, STOCKSYMBOL + " = ?", new String[]{stock.getStockSymbol()});
        //Log.d(TAG, "updateStock: " + numRows);
    }

    void deleteStock(String stockSymbol) {
        int temp = database.delete(TABLE_NAME, STOCKSYMBOL + " = ?", new String[]{stockSymbol});
    }

    void dumpDbToLog() {
        Cursor cursor = database.rawQuery("select * from " + TABLE_NAME, null);
        if (cursor != null) {
            cursor.moveToFirst();

            for (int i = 0; i < cursor.getCount(); i++) {
                String stockSymbol = cursor.getString(0);
                String companyName = cursor.getString(1);
                double price = cursor.getDouble(2);
                double priceChange = cursor.getDouble(3);
                double changePercent = cursor.getDouble(4);
                Log.d(TAG, "dumpDbToLog: " +
                        String.format("%s %-18s", STOCKSYMBOL + ":", stockSymbol) +
                        String.format("%s %-18s", COMPANYNAME + ":", companyName) +
                        String.format("%s %-18s", PRICE + ":", price) +
                        String.format("%s %-18s", PRICECHANGE + ":", priceChange) +
                        String.format("%s %-18s", CHANGEPERCENT + ":", changePercent));
                cursor.moveToNext();
            }
            cursor.close();
        }
    }

    void shutDown() {
        database.close();
    }

}
