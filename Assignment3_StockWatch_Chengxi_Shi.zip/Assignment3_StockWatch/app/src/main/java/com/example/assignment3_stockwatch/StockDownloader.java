package com.example.assignment3_stockwatch;

import android.net.Uri;
import android.os.AsyncTask;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class StockDownloader extends AsyncTask<String, Void, Stock> {

    private static final String TAG = "NameDownloader";
    private MainActivity mainActivity;
    private boolean updateFlag = false;
    private static final String realtimeURl = "https://cloud.iexapis.com/stable/stock/";
    private static final String yourAPIKey = "/quote?token=pk_1aca119300584fc1b2174e80ae37f48c";

    StockDownloader(MainActivity ma){
        mainActivity = ma;
    }

    @Override
    protected void onPostExecute(Stock stock) {
        mainActivity.doADDStock(stock);
    }

    @Override
    protected Stock doInBackground(String... params) {
        String stocks = params[0];
        if(params.length>1){
            updateFlag = true;
        }
        String urlmaking = realtimeURl + stocks + yourAPIKey;

        //url building - open the url
        Uri.Builder buildURL = Uri.parse(urlmaking).buildUpon();
        String urlToUse = buildURL.build().toString();
        //end url build

        StringBuilder sb = new StringBuilder();
        try{
            URL url = new URL(urlToUse);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.connect();

            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK)
                return null;

            InputStream is = connection.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));

            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }

        } catch (Exception e){
            return null;
        }
        //open the json function
        return parseJSON(sb.toString());
    }

    private Stock parseJSON(String s){
        try{
            JSONObject jObjMain = new JSONObject(s);

            //stock symbol
            String stockSymbol = jObjMain.getString("symbol");

            //company name
            String companyName = jObjMain.getString("companyName");

            //price
            String price = String.format("%.2f",jObjMain.getDouble("latestPrice"));

            //priceChange
            String priceChange = String.format("%.2f",jObjMain.getDouble("change"));

            //changePercent
            String changePercent = String.format("%.2f",jObjMain.getDouble("changePercent"));
            if(updateFlag == true){
                mainActivity.databaseHandler.updateStock(new Stock(stockSymbol, companyName, price, priceChange, changePercent));
                return null;
            }
            else{
                return new Stock(stockSymbol, companyName, price, priceChange, changePercent);
            }


        } catch (Exception e){
            e.printStackTrace();
        }

        return null;
    }
}
