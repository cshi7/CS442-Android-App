package com.example.assign5_newsgateway;

import android.annotation.SuppressLint;
import android.net.Uri;
import android.os.AsyncTask;
import android.text.util.Linkify;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class AsyncNewsSourceDownloader extends AsyncTask<String,Integer,String> {

    private MainActivity mainActivity;
    private ArrayList<News> newsList = new ArrayList<>();
    private static final String newsURL = "https://newsapi.org/v2/sources?language=en&country=us&category=&apiKey=9952554b562d45f8a1729628813d3cb2";

    AsyncNewsSourceDownloader(MainActivity ma){
        mainActivity = ma;
    }

    @Override
    protected void onPostExecute(String s) {
        ArrayList<News> newsList_t = parseJSON(s);
        if (newsList_t != null) {
            mainActivity.sourceDownloadSetting(newsList_t);
        }
    }

    @Override
    protected String doInBackground(String... strings) {
        Uri.Builder buildURL = Uri.parse(newsURL).buildUpon();
        String urlToUse = buildURL.build().toString();

        StringBuilder sb = new StringBuilder();
        try{
            URL url = new URL(urlToUse);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.connect();

            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK)
                return null;

            InputStream is = connection.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));

            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }

        } catch (Exception e){
            return null;
        }

        return sb.toString();
    }

    private  ArrayList<News> parseJSON(String s) {
        String sourceName;
        String sourceID;
        String sourceCategory;

        try{
            JSONObject jObjMain = new JSONObject(s);
            JSONArray source = jObjMain.getJSONArray("sources");
            for(int i=0;i<source.length();i++){
                JSONObject newsSource = source.getJSONObject(i);
                sourceName = newsSource.getString("name");
                sourceID = newsSource.getString("id");
                sourceCategory = newsSource.getString("category");
                newsList.add(new News(sourceName,sourceID,sourceCategory));
            }
            return newsList;
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
}
