package com.example.assign5_newsgateway;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.graphics.Point;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private DrawerLayout mDrawerLayout;
    private ListView mDrawerList;
    private ActionBarDrawerToggle mDrawerToggle;

    private Menu news_category;
    private ArrayList<News> newsList = new ArrayList<>();
    private HashMap<String, ArrayList<News>> newsData = new HashMap<>();

    private SampleReceiver sampleReceiver;
    static final String NEWS_GET_BROADCAST_FROM_SERVICE = "NEWS_GET_BROADCASR_FROM_SERVICE";
    static final String MESSAGE_BROADCAST_FROM_SERVICE = "MESSAGE_BROADCAST_FROM_SERVICE";
    static final String NEWS_DATA = "NEWS_DATA";
    static final String MESSAGE_DATA = "MESSAGE_DATA";

    String[] init_drawer;

    private List<Fragment> fragments;
    private MyPageAdapter pageAdapter;
    private ViewPager pager;
    public static int screenWidth, screenHeight;
    private String currentNewsSource;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //after get the data from NewsAPI.org, then create the news source and news category
        //details in example GeographicDrawerLayout, week 13
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        screenWidth = size.x;
        screenHeight = size.y;

        sampleReceiver = new SampleReceiver();
        IntentFilter filter1 = new IntentFilter(NEWS_GET_BROADCAST_FROM_SERVICE);
        registerReceiver(sampleReceiver, filter1);

        IntentFilter filter2 = new IntentFilter(MESSAGE_BROADCAST_FROM_SERVICE);
        registerReceiver(sampleReceiver, filter2);

        mDrawerLayout = findViewById(R.id.drawer_layout);
        mDrawerList = findViewById(R.id.left_drawer);

        mDrawerList.setOnItemClickListener(
                new ListView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        selectItem(position);
                        News n = newsList.get(position);
                        // Intent intent = new Intent(MainActivity.this, NewsDetailActivity.class);
                        // intent.putExtra(News.class.getName(), n);
                        // startActivity(intent);
                        mDrawerLayout.closeDrawer(mDrawerList);
                    }
                }
        );

        mDrawerToggle = new ActionBarDrawerToggle(this,mDrawerLayout,R.string.drawer_open,R.string.drawer_close);

        fragments = new ArrayList<>();
        pageAdapter = new MyPageAdapter(getSupportFragmentManager());
        pager = findViewById(R.id.viewpager);
        pager.setAdapter(pageAdapter);

        if(newsData.isEmpty()){
            doAsyncSourceDownload();
        }
    }

    private void doAsyncSourceDownload() {
        new AsyncNewsSourceDownloader(this).execute();
    }


    public void sourceDownloadSetting(ArrayList<News> newsArrayList){
        for (News ns:newsArrayList){
            // put source category into newsSourceData
            if(!newsData.containsKey(ns.getSourceCategory())){
                newsData.put(ns.getSourceCategory(),new ArrayList<News>());
            }
            ArrayList<News> nslist = newsData.get(ns.getSourceCategory());
            if (nslist != null) {
                nslist.add(ns);
            }
        }

        newsData.put("All",newsArrayList);
        ArrayList<String> nList = new ArrayList<>(newsData.keySet());
        for(String s : nList)
            news_category.add(s);

        newsList.addAll(newsArrayList);
        mDrawerList.setAdapter(new ArrayAdapter<>(this, R.layout.news_drawer_list_item, newsList));

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
        }
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (mDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        setTitle(item.getTitle());

        newsList.clear();
        ArrayList<News> nlist = newsData.get(item.getTitle().toString());
        if (nlist != null) {
            newsList.addAll(nlist);
        }

        ((ArrayAdapter) mDrawerList.getAdapter()).notifyDataSetChanged();
        return super.onOptionsItemSelected(item);
    }

    private void selectItem(int position) {
        //Toast.makeText(this, newsList.get(position).getSource(),Toast.LENGTH_SHORT).show();
        stopService();
        pager.setBackground(null);
        //new AsyncNewsDownloader(this).execute(newsList.get(position).getSourceID());
        callNewsService(newsList.get(position).getSourceID());
        mDrawerLayout.closeDrawer(mDrawerList);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.news_category, menu);
        news_category = menu;
        return true;
    }

    public void callNewsService(String s){
        Intent intent = new Intent(MainActivity.this, NewsService.class);
        intent.putExtra("DOWNLOAD_NEWS_LIST", s);
        startService(intent);
    }

    public void stopService() {
        Intent intent = new Intent(MainActivity.this, NewsService.class);
        stopService(intent);
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(sampleReceiver);
        Intent intent = new Intent(MainActivity.this, NewsService.class);
        stopService(intent);
        super.onDestroy();
    }

    //////////////////////////////////////////
    //class for sample receiver
    class SampleReceiver extends BroadcastReceiver{
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if(action == null)
                return;
            switch (action){
                case NEWS_GET_BROADCAST_FROM_SERVICE:
                    ArrayList<News> passedNewsList = new ArrayList<>();
                    if(intent.hasExtra(NEWS_DATA))
                        passedNewsList = (ArrayList<News>) intent.getSerializableExtra(NEWS_DATA);
                    if(passedNewsList!=null)
                        setupNews(passedNewsList);
                    break;
                case MESSAGE_BROADCAST_FROM_SERVICE:
                    String data = "";
                    if (intent.hasExtra(MESSAGE_DATA))
                        data = intent.getStringExtra(MESSAGE_DATA);
                    Log.d(TAG, data);
                    break;
                default:
                    Log.d(TAG, "onReceive: Unknown broadcast received");
                    break;
            }
        }
    }

    ///////////////////////////////////////////
    //class for pageAdapter
    public void setupNews(ArrayList<News> newsArrayList){
        setTitle(currentNewsSource);

        for(int i=0;i<pageAdapter.getCount();i++){
            pageAdapter.notifyChangeInPosition(i);
        }
        fragments.clear();
        for (int i = 0; i < newsArrayList.size(); i++) {
            fragments.add(
                    NewsFragment.newInstance(newsArrayList.get(i), i+1, newsArrayList.size()));
        }
        pageAdapter.notifyDataSetChanged();
        pager.setCurrentItem(0);
    }

    private class MyPageAdapter extends FragmentPagerAdapter{

        private long baseID = 0;
        MyPageAdapter(FragmentManager fm) {
            super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        }

        @Override
        public int getItemPosition(@NonNull Object object) {
            return POSITION_NONE;
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            return fragments.get(position);
        }

        @Override
        public int getCount() {
            return fragments.size();
        }

        @Override
        public long getItemId(int position) {
            // give an ID different from position when position has been changed
            return baseID + position;
        }

        void notifyChangeInPosition(int n) {
            // shift the ID returned by getItemId outside the range of all previous fragments
            baseID += getCount() + n;
        }
    }
}
