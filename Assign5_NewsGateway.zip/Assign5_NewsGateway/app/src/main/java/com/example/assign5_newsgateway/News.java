package com.example.assign5_newsgateway;

import android.graphics.Bitmap;

import androidx.annotation.NonNull;

import java.io.Serializable;

public class News implements Serializable{
    private String source;
    private String source_id;
    private String source_category;
    private String articleName;
    private String authorName;
    private String title;
    private String description;
    private String url;
    private String urlToImage;
    private String publishedAt;
    private Bitmap bitmap;


    News(String ss,String si,String sc,String an,String authorN,String t,String d,String u,String uti,String p,Bitmap bit){
        source = ss;
        source_id = si;
        source_category = sc;
        articleName = an;
        authorName = authorN;
        title = t;
        description = d;
        url = u;
        urlToImage = uti;
        publishedAt = p;
        bitmap = bit;
    }

    News(String a,String b,String c){
        source = a;
        source_id = b;
        source_category = c;
        articleName = "";
        authorName = "";
        title = "";
        description = "";
        url = "";
        urlToImage = "";
        publishedAt = "";
        bitmap = null;
    }

    String getSource(){
        return source;
    }

    String getSourceID(){
        return source_id;
    }

    String getSourceCategory(){
        return source_category;
    }

    String getArticleName(){
        return articleName;
    }

    String getAuthorName(){
        return authorName;
    }

    String getTitle(){
        return title;
    }

    String getDescription(){
        return description;
    }

    String getUrl(){
        return url;
    }

    String getUrlToImage(){
        return urlToImage;
    }

    String getPublishedAt(){
        return publishedAt;
    }

    Bitmap getBitmap(){
        return bitmap;
    }

    //this will affect the display of left drawer
    @NonNull
    public String toString() {
        return source;
    }
}

