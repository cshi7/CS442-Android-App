package com.example.assign5_newsgateway;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class NewsFragment extends Fragment {
    public NewsFragment(){
    }

    static NewsFragment newInstance(News news,int index, int max)
    {
        NewsFragment n = new NewsFragment();
        Bundle bdl = new Bundle(1);
        bdl.putSerializable("NEWS_DATA", news);
        bdl.putSerializable("INDEX", index);
        bdl.putSerializable("TOTAL_COUNT", max);
        n.setArguments(bdl);
        return n;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View fragment_layout = inflater.inflate(R.layout.fragment_news, container, false);
        Bundle args = getArguments();
        if(args!=null){
            final News currentNews = (News) args.getSerializable("NEWS_DATA");
            if(currentNews == null){
                return null;
            }
            int index = args.getInt("INDEX");
            int total = args.getInt("TOTAL_COUNT");

            getActivity().setTitle(currentNews.getSource());
            fragment_layout.setBackgroundColor(Color.parseColor("#157EA6"));

            final String url = currentNews.getUrl();

            TextView newsTitle = fragment_layout.findViewById(R.id.newsTitle);
            newsTitle.setText(currentNews.getTitle());
            newsTitle.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onClickView(url);
                }
            });

            TextView newsDate = fragment_layout.findViewById(R.id.newsDate);
            String tempDate = currentNews.getPublishedAt();
            tempDate = tempDate.replace('T',' ');
            tempDate = tempDate.replace('Z',' ');

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd' 'HH:mm:ss");
            try {
                Date date = sdf.parse(tempDate);
                SimpleDateFormat newsdf = new SimpleDateFormat("MMM' 'dd,' 'yyyy' 'HH:mm");
                newsDate.setText(newsdf.format(date));

            } catch (ParseException e) {
                e.printStackTrace();
            }
            //newsDate.setText(tempDate);
            /*try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
                Date date = sdf.parse(tempDate);
                SimpleDateFormat newsdf = new SimpleDateFormat("MMM' 'dd,yyyy' 'HH:mm");
                newsDate.setText(newsdf.format(date));
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
                Date date = sdf.parse(tempDate.replaceAll("Z$", "+0000"));
                SimpleDateFormat outputFormat = new SimpleDateFormat("hh:mm a", Locale.ENGLISH);

            } catch (ParseException e) {
                e.printStackTrace();
            }*/

            TextView newsAuthor = fragment_layout.findViewById(R.id.newsAuthor);
            newsAuthor.setText(currentNews.getAuthorName());

            TextView newsDescription = fragment_layout.findViewById(R.id.newsDescription);
            newsDescription.setText(currentNews.getDescription());
            newsDescription.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onClickView(url);
                }
            });

            TextView pageNum = fragment_layout.findViewById(R.id.pageViewer);
            pageNum.setText(String.format(Locale.US, "%d of %d", index, total));

            if(currentNews.getBitmap()!=null){
                ImageView imageView = fragment_layout.findViewById(R.id.newImage);
                imageView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
                imageView.setImageBitmap(currentNews.getBitmap());
                imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onClickView(url);
                    }
                });
            }
            return fragment_layout;
        }
        else{
            return null;
        }
    }

    public void onClickView(String s){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(s));
        startActivity(intent);
    }
}
