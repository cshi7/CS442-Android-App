package com.example.assign5_newsgateway;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class AsyncNewsDownloader extends AsyncTask<String,Integer,ArrayList<News>>{

    private MainActivity mainActivity;
    private ArrayList<News> newsList = new ArrayList<>();
    private static final String newsURL = "https://newsapi.org/v2/everything?sources=";
    private static final String APIkey = "&language=en&pageSize=100&apiKey=9952554b562d45f8a1729628813d3cb2";

    AsyncNewsDownloader(MainActivity ma){
        mainActivity = ma;
    }

    @Override
    protected ArrayList<News> doInBackground(String... params) {
        String urlBuild = newsURL + params[0] + APIkey;
        Uri.Builder buildURL = Uri.parse(urlBuild).buildUpon();
        String urlToUse = buildURL.build().toString();

        StringBuilder sb = new StringBuilder();
        try{
            URL url = new URL(urlToUse);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.connect();

            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK)
                return null;

            InputStream is = connection.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));

            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }

        } catch (Exception e){
            return null;
        }

        return parseJSON(sb.toString());
    }

    @Override
    protected void onPostExecute(ArrayList<News> newsArrayList) {
         mainActivity.setupNews(newsArrayList);
    }

    private ArrayList<News> parseJSON(String s){
        ArrayList<News> newsList = new ArrayList<>();
        try{
            JSONObject jObjMain = new JSONObject(s);
            JSONArray jNews = (JSONArray) jObjMain.get("articles");

            for(int i=0;i<jNews.length();i++){
                JSONObject tempNews = jNews.getJSONObject(i);
                JSONObject articleInfo = tempNews.getJSONObject("source");
                String newsSourceID = articleInfo.getString("id");
                String newsSourceName = articleInfo.getString("name");
                String newsAuthor = tempNews.getString("author");
                String newsTitle = tempNews.getString("title");
                String newsDescription = tempNews.getString("description");
                String newsUrl = tempNews.getString("url");
                String newsUrlToImage = tempNews.getString("urlToImage");
                //String newsUrlToImage = "https://dynaimage.cdn.cnn.com/cnn/w_1200/http%3A%2F%2Fcdn.cnn.com%2Fcnnnext%2Fdam%2Fassets%2F190322082046-05-pride-parade-explainer-photos-super-tease.jpg";
                String newsPublish = tempNews.getString("publishedAt");

                if(newsUrlToImage!=null&&!newsUrlToImage.equals("null")){
                    URL url = new URL(newsUrlToImage);
                    Bitmap bmp = BitmapFactory.decodeStream(url.openConnection().getInputStream());
                    newsList.add(new News(newsSourceName,newsSourceID,"","",newsAuthor,newsTitle,newsDescription,newsUrl,newsUrlToImage,newsPublish,bmp));
                }
                else{
                    newsList.add(new News(newsSourceName,newsSourceID,"","",newsAuthor,newsTitle,newsDescription,newsUrl,newsUrlToImage,newsPublish,null));
                }
                //imageView.setImageBitmap(bmp);
            }
            boolean nullCheckFlag = false;
            while(true){
                if(newsList.size()>10 && nullCheckFlag == false){
                    for(int i=0;i<newsList.size();i++){
                        News tempNews = newsList.get(i);
                        if(tempNews.getDescription().equals(null)||tempNews.getDescription().equals("null")
                                ||tempNews.getAuthorName().equals(null)||tempNews.getAuthorName().equals("null")
                                ||tempNews.getTitle().equals(null)||tempNews.getTitle().equals("null")
                                ||tempNews.getArticleName().equals(null)||tempNews.getArticleName().equals("null")
                                ||tempNews.getUrl().equals(null)||tempNews.getUrl().equals("null")){
                            newsList.remove(i);
                            break;
                        }
                        if(i == newsList.size()-1){
                            nullCheckFlag = true;
                        }
                    }
                }
                else{
                    break;
                }
                if(nullCheckFlag){
                    while(newsList.size()>10){
                        newsList.remove(newsList.size()-1);
                    }
                }
            }
            return newsList;
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }


}
