package com.example.assign4_knowyourgovernment;

import android.net.Uri;
import android.os.AsyncTask;

import androidx.appcompat.app.AlertDialog;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class GoogleDownloader extends AsyncTask<String, Void, List<Officials>>{

    private static final String TAG = "GoogleCivicInfoDownloader";
    private MainActivity mainActivity;
    private List<Officials> officialList = new ArrayList<>();
    private static final String realtimeURl = "https://www.googleapis.com/civicinfo/v2/representatives?key=AIzaSyA-lJpsQbgk56EoI1VF0gbwZjXVbJJ2YRk&address=";

    GoogleDownloader(MainActivity ma){
        mainActivity = ma;
    }

    @Override
    protected void onPostExecute(List<Officials> officials) {
        mainActivity.doSetRecycler(officials);
    }

    @Override
    protected List<Officials> doInBackground(String... params) {
        String address = params[0];
        String urlmaking = realtimeURl + address;

        Uri.Builder buildURL = Uri.parse(urlmaking).buildUpon();
        String urlToUse = buildURL.build().toString();

        StringBuilder sb = new StringBuilder();
        try{
            URL url = new URL(urlToUse);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.connect();

            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK)
                return null;

            InputStream is = connection.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));

            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }

        } catch (Exception e){
            return null;
        }

        return parseJSON(sb.toString());
    }

    private List<Officials> parseJSON(String s){
        String location = "";
        String st_0 = "";
        String st_1 = "";
        String officials_name= "";
        String officials_address = "";
        String party = "";
        String phones = "";
        String urls ="";
        String emails = "";
        String photoURL = "";
        String cl = "";

        try{
            JSONObject jObjMain = new JSONObject(s);

            //location is like {"line1":"","city":"Chicago","state":"IL","zip":"60616"}
            JSONObject Location_1 = jObjMain.getJSONObject("normalizedInput");
            String zip = Location_1.getString("zip");
            String city = Location_1.getString("city");
            String state = Location_1.getString("state");

            if(zip.isEmpty()){
                if(city.isEmpty()){
                    location = state;
                }
                else{
                    location = city+","+state;
                }
            }
            else{
                if(city.isEmpty()){
                    location = state+","+zip;
                }
                else{
                    location = city + "," + state + "," + zip;
                }
            }

            JSONArray Offices_1 = jObjMain.getJSONArray("offices");
            //have a loop here
            ArrayList<String> ar = new ArrayList<>();
            for(int i=0;i<Offices_1.length();i++){

                //Offices contains all of the office titles in this location
                JSONObject temp = (JSONObject)Offices_1.get(i);
                String offices_name = temp.getString("name");

                //because indices can have more than one value, so we want the several indices to be different object
                String official_indices = temp.getString("officialIndices");

                //get the length of the indices
                //if it contains only one value, the length should <=2
                //if it contains two or more value, the least length should be >=3
                official_indices = official_indices.substring(1,official_indices.length()-1);
                if(official_indices.length()>=3){
                    String[] a = official_indices.split(",");
                    for(int j=0;j<a.length;j++){
                        ar.add(offices_name+","+a[j]);
                    }
                }
                else{
                    ar.add(offices_name+","+official_indices);
                }
                //add all the things together later
                //officialList.add(new Officials());
            }

            JSONArray Officials_1 = jObjMain.getJSONArray("officials");
            for(int i=0;i<ar.size();i++){
                //get index from ar, which is offices indices
                st_0 = ar.get(i).split(",")[0];
                st_1 = ar.get(i).split(",")[1];

                //int index_ar = Integer.parseInt(ar.get(i).split(",")[1]);
                int index_ar = Integer.parseInt(st_1);
                JSONObject temp = (JSONObject)Officials_1.get(index_ar);
                officials_name = temp.getString("name");

                if(temp.has("address")){
                JSONArray officialsAddress = temp.getJSONArray("address");
                officials_address = officialsAddress.getJSONObject(0).getString("line1")+","+officialsAddress.getJSONObject(0).getString("city")+","
                        +officialsAddress.getJSONObject(0).getString("state")+","+officialsAddress.getJSONObject(0).getString("zip");}

                if(temp.has("party")){
                party = temp.getString("party");}

                //use substring to get phone value
                if(temp.has("phones")){
                    phones = temp.getString("phones");
                    phones = phones.substring(2,phones.length()-2);
                }

                if(temp.has("urls")){
                    urls = temp.getString("urls");
                    //e.g.,urls = "http:\/\/www.whitehouse.gov\/"

                    urls = urls.replace("\\", "");
                    urls = urls.substring(2,urls.length()-2);
                }

                //it has the situation that the person does not provide the email address
                if(temp.has("emails")){
                    emails = temp.getString("emails");
                    emails = emails.substring(2,emails.length()-2);
                }

                if(temp.has("photoUrl")){
                photoURL = temp.getString("photoUrl");}

                //temp.getString("channels"); = [{"type":"Facebook","id":"DonaldTrump"},{"type":"Twitter","id":"potus"},{"type":"YouTube","id":"whitehouse"}]
                if(temp.has("channels")){
                JSONArray channels = temp.getJSONArray("channels");
                ArrayList<String> channelList = new ArrayList<>();
                for(int j=0;j<channels.length();j++){
                    JSONObject subChannel = (JSONObject) channels.get(j);
                    String contact = subChannel.getString("type")+","+subChannel.getString("id");
                    channelList.add(contact);
                }

                cl = channelList.toString();}
                officialList.add(new Officials(location, st_0, st_1, officials_name, officials_address, party, phones, urls, emails, photoURL, cl));

                st_0 = "";
                st_1 = "";
                officials_name= "";
                officials_address = "";
                party = "";
                phones = "";
                urls ="";
                emails = "";
                photoURL = "";
                cl = "";

            }
            return officialList;
        } catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
}
