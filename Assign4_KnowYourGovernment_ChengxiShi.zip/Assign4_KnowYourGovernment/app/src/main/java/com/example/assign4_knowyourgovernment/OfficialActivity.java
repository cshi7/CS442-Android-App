package com.example.assign4_knowyourgovernment;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;


public class OfficialActivity extends AppCompatActivity {
    private static final String TAG = "OfficialActivity";
    private String faceID = "";
    private String twiID = "";
    private String youtID = "";
    private String googID = "";
    private String channelID = "";
    private int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_official_a);
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);

        TextView textView;
        ImageView imageView = findViewById(R.id.photo);

        Boolean netFlag = doNetCheck();

        Intent intent = getIntent();
        if (intent.hasExtra(Intent.EXTRA_TEXT)) {
            String text = intent.getStringExtra(Intent.EXTRA_TEXT);
            final String[] info = text.split(";");

            //set search address
            textView = findViewById(R.id.searchAddress);
            textView.setText(info[4]);

            textView = findViewById(R.id.officeName);
            textView.setText(info[0]);
            textView = findViewById(R.id.officialName);
            textView.setText(info[1]);
            textView = findViewById(R.id.party);
            textView.setText("(" + info[2] + ")");

            Picasso picasso = new Picasso.Builder(this).build();
            LinearLayout ll = findViewById(R.id.linearView);

            if (!info[3].isEmpty()) {
                picasso.load(info[3])
                        .error(R.drawable.brokenimage)
                        .placeholder(R.drawable.placeholder)
                        .into(imageView);
            } else {
                picasso.load(R.drawable.missing)
                        .into(imageView);
            }
            if(!netFlag){
                picasso.load(R.drawable.brokenimage)
                        .into(imageView);
            }

            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(doNetCheck()){
                        //sequence photoURL, searchAddress, officeName, officialName, partyInfo
                        String passText = info[3]+";"+info[4]+";"+info[0]+";"+info[1]+";"+info[2];
                        Intent intent = new Intent(OfficialActivity.this, PhotoActivity.class);
                        intent.putExtra("EXTRA_INFO",passText);
                        startActivity(intent);
                    }
                }
            });

            imageView = findViewById(R.id.partyIcon);
            //Republican Party
            //Democratic Party
            //other
            String partyInformation = info[2];

            if (partyInformation.compareTo("Republican Party") == 0) {
                picasso.load(R.drawable.rep_logo)
                        .placeholder(R.drawable.ic_launcher)
                        .into(imageView);

                imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(doNetCheck()){
                            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.gop.com/"));
                            startActivity(intent);
                        }
                    }
                });

                ll.setBackgroundColor(Color.parseColor("#ff0000"));
            } else if (partyInformation.compareTo("Democratic Party") == 0) {
                picasso.load(R.drawable.dem_logo)
                        .placeholder(R.drawable.ic_launcher)
                        .into(imageView);

                imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(doNetCheck()){
                            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://democrats.org/"));
                            startActivity(intent);
                        }
                    }
                });

                ll.setBackgroundColor(Color.parseColor("#0000ff"));
            } else {
                ll.setBackgroundColor(Color.parseColor("#000000"));
            }

            if (!info[5].isEmpty()) {
                textView = findViewById(R.id.addressDetail);
                String str_text = "<a href=https://www.google.com/maps/place/"+info[5]+">"+info[5]+"</a>";
                textView.setText(Html.fromHtml(str_text));
                //textView.setClickable(true);
                //textView.setMovementMethod(LinkMovementMethod.getInstance());;
                Linkify.addLinks(textView,Linkify.ALL);
            }

            if (!info[6].isEmpty()) {
                textView = findViewById(R.id.phoneDetail);
                textView.setText(info[6]);

                Linkify.addLinks(textView, Linkify.ALL);
            }

            if (!info[8].isEmpty()) {
                textView = findViewById(R.id.email);
                textView.setText("Email: ");
                textView = findViewById(R.id.emailDetail);
                textView.setText(info[8]);
                Linkify.addLinks(textView, Linkify.ALL);
            }

            if (!info[7].isEmpty()) {
                textView = findViewById(R.id.websiteDetail);
                textView.setText(info[7]);
                Linkify.addLinks(textView, Linkify.ALL);
            }

            if (!info[9].isEmpty()) {
                String temp = info[9].substring(1, info[9].length() - 1);
                temp = temp.replaceAll("\\s+", "");
                //Facebook,DonaldTrump, Twitter,potus, YouTube,whitehouse
                String[] channel = temp.split(",");
                int chaLength = channel.length / 2;

                for (int i = 0; i < chaLength; i++) {
                    //use counter to determine which imageView should we use
                    switch (counter) {
                        case 0:
                            imageView = findViewById(R.id.imageView_0);
                            break;
                        case 1:
                            imageView = findViewById(R.id.imageView_1);
                            break;
                        case 2:
                            imageView = findViewById(R.id.imageView_2);
                            break;
                        case 3:
                            imageView = findViewById(R.id.imageView_3);
                            break;
                    }
                    switch (channel[i * 2]) {
                        case "Facebook":
                            picasso.load(R.drawable.facebook)
                                    .into(imageView);
                            faceID = channel[i * 2 + 1];
                            imageView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    facebookClicked(v);
                                }
                            });
                            counter++;
                            break;
                        case "Twitter":
                            picasso.load(R.drawable.twitter)
                                    .into(imageView);
                            twiID = channel[i * 2 + 1];
                            imageView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    twitterClicked(v);
                                }
                            });
                            counter++;
                            break;
                        case "YouTube":
                            picasso.load(R.drawable.youtube)
                                    .into(imageView);
                            youtID = channel[i * 2 + 1];
                            imageView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    youTubeClicked(v);
                                }
                            });
                            counter++;
                            break;
                        case "Google+":
                            picasso.load(R.drawable.googleplus)
                                    .into(imageView);
                            googID = channel[i * 2 + 1];
                            imageView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    googlePlusClicked(v);
                                }
                            });
                            counter++;
                            break;
                        default:
                            break;
                    }
                }
                counter = 0;
            }
        }
    }

    private Boolean doNetCheck() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) {
            Toast.makeText(this, "Cannot access ConnectivityManager", Toast.LENGTH_SHORT).show();
            return false;
        }
        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        if (netInfo != null && netInfo.isConnected()) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public void twitterClicked(View v) {
        Intent intent = null;
        //the official’s twitter id from download
        String name = twiID;
        try {
            // get the Twitter app if possible
            getPackageManager().getPackageInfo("com.twitter.android", 0);
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("twitter://user?screen_name=" + name));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        } catch (Exception e) {
            // no Twitter app, revert to browser
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/" + name));
        }
        startActivity(intent);
    }

    public void facebookClicked(View v) {
        String FACEBOOK_URL = "https://www.facebook.com/" + faceID;
        String urlToUse;
        urlToUse = FACEBOOK_URL;
        Intent facebookIntent = new Intent(Intent.ACTION_VIEW);
        facebookIntent.setData(Uri.parse(urlToUse));
        startActivity(facebookIntent);
    }

    public void youTubeClicked(View v) {
        String name = youtID;
        Intent intent = null;
        try {
            intent = new Intent(Intent.ACTION_VIEW);
            intent.setPackage("com.google.android.youtube");
            intent.setData(Uri.parse("https://www.youtube.com/" + name));
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/" + name)));
        }
    }

    public void googlePlusClicked(View v) {
        String name = googID;
        Intent intent = null;
        try {
            intent = new Intent(Intent.ACTION_VIEW);
            intent.setClassName("com.google.android.apps.plus",
                    "com.google.android.apps.plus.phone.UrlGatewayActivity");
            intent.putExtra("customAppUri", name);
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://plus.google.com/" + name)));
        }
    }
}
