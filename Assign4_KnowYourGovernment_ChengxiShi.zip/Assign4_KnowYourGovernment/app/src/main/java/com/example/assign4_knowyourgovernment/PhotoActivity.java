package com.example.assign4_knowyourgovernment;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.squareup.picasso.Picasso;


public class PhotoActivity extends AppCompatActivity{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo);
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);

        TextView textView;
        ImageView imageView = findViewById(R.id.photo_Photo);
        Intent intent = getIntent();
        Bundle extra = intent.getExtras();

        if (extra!=null) {
            //sequence photoURL, searchAddress, officeName, officialName, partyInfo
            String[] passInfo = extra.getString("EXTRA_INFO").split(";");

            textView = findViewById(R.id.searchAddressPhoto);
            textView.setText(passInfo[1]);

            textView = findViewById(R.id.officesNamePhoto);
            textView.setText(passInfo[2]);

            textView = findViewById(R.id.officialNamePhoto);
            textView.setText(passInfo[3]);

            Picasso picasso = new Picasso.Builder(this).build();
            ConstraintLayout cl = findViewById(R.id.clPhoto);

            if (!passInfo[0].isEmpty()) {
                picasso.load(passInfo[0])
                        .error(R.drawable.brokenimage)
                        .placeholder(R.drawable.placeholder)
                        .into(imageView);
            } else {
                picasso.load(R.drawable.missing)
                        .into(imageView);
            }

            imageView = findViewById(R.id.partyIcon_Photo);
            String partyInformation = passInfo[4];

            if (partyInformation.compareTo("Republican Party") == 0) {
                picasso.load(R.drawable.rep_logo)
                        .placeholder(R.drawable.ic_launcher)
                        .into(imageView);

                cl.setBackgroundColor(Color.parseColor("#ff0000"));
            } else if (partyInformation.compareTo("Democratic Party") == 0) {
                picasso.load(R.drawable.dem_logo)
                        .placeholder(R.drawable.ic_launcher)
                        .into(imageView);

                cl.setBackgroundColor(Color.parseColor("#0000ff"));
            } else {
                cl.setBackgroundColor(Color.parseColor("#000000"));
            }
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}

