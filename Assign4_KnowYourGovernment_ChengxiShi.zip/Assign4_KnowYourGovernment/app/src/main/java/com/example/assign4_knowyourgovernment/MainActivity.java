package com.example.assign4_knowyourgovernment;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import java.net.HttpURLConnection;
import java.net.URL;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.InputType;
import android.util.JsonWriter;
import android.util.Log;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.URLUtil;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private List<Officials> officialList = new ArrayList<>();
    private static final String TAG = "MainActivity";
    private RecyclerView recyclerView;
    private OfficialAdapter mAdapter;
    private TextView textView;
    private String temp = "";
    private boolean locationResult;
    private static final String realtimeURl = "https://www.googleapis.com/civicinfo/v2/representatives?key=AIzaSyA-lJpsQbgk56EoI1VF0gbwZjXVbJJ2YRk&address=";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView);

        recyclerView = findViewById(R.id.recycler);

        mAdapter = new OfficialAdapter(officialList,this);
        recyclerView.setAdapter(mAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    @Override
    protected void onResume() {
        if(!doNetworkCheck()){
            textView.setText("No Data For Location");
            networkDialogBuild();
        }
        super.onResume();
    }

    private boolean doNetworkCheck() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) {
            Toast.makeText(this, "Cannot access ConnectivityManager", Toast.LENGTH_SHORT).show();
            return false;
        }
        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        if (netInfo != null && netInfo.isConnected()) {
            return true;
        } else {
            return false;
        }
    }
    /*
    private String loadFile() {
        String s = "";
        try {
            InputStream is = getApplicationContext().
                    openFileInput("Location.json");

            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));

            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }

            JSONObject jsonObject = new JSONObject(sb.toString());
            s = jsonObject.getString("Location");

        } catch (FileNotFoundException e) {
            //Toast.makeText(this, "NO FILE", Toast.LENGTH_SHORT).show();
            return null;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return s;
    }

    @Override
    protected void onPause() {
        String s = temp;
        saveLocation(s);
        super.onPause();
    }

    private void saveLocation(String s) {
        try {
            FileOutputStream fos = getApplicationContext().
                    openFileOutput("Location.json", Context.MODE_PRIVATE);
            JsonWriter writer = new JsonWriter(new OutputStreamWriter(fos, "UTF-8"));
            writer.setIndent("  ");
            writer.beginObject();
            writer.name("Location").value(s);
            writer.endObject();
            writer.close();
        } catch (Exception e) {
            e.getStackTrace();
        }
    }*/

    @Override
    public void onClick(View v) {
        int pos = recyclerView.getChildLayoutPosition(v);
        Officials o = officialList.get(pos);

        Intent intent = new Intent(MainActivity.this, OfficialActivity.class);
        intent.putExtra(Intent.EXTRA_TEXT, o.toString());
        startActivity(intent);

        //Toast.makeText(v.getContext(), "SHORT " + o.toString(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.action_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.aboutAction:
                if(doNetworkCheck()){
                    openNewActivity(textView);
                    return true;
                }
                else{
                    networkDialogBuild();
                    return false;
                }

            case R.id.searchAction:
                if(doNetworkCheck()){
                    searchDialogBuild();
                    return true;
                }
                else{
                    networkDialogBuild();
                    return false;
                }
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void openNewActivity(View v) {
        Intent intent = new Intent(MainActivity.this,AboutActivity.class);
        startActivity(intent);
    }

    public void searchDialogBuild(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Enter a City, State or a Zip Code: ");
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        builder.setView(input);

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                temp = input.getText().toString();
                doLocationCheck(temp);
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    public void networkDialogBuild(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("No NetWork Connection");
        builder.setMessage("Data cannot be accessed/loaded without an internet connection");
        builder.show();
    }

    public void doLocationCheck(String s){
        new locationCheck(this).execute(s);
    }
    public void doAsyncGD(String s){
        if(locationResult){
            temp = "";
            new GoogleDownloader(this).execute(s);
        }
        else{
            temp = "";
            locationDialogBuild();
        }
    }

    public void doSetRecycler(List<Officials> officials){
        officialList.removeAll(officialList);
        for(int i=0;i<officials.size();i++){
            officialList.add(officials.get(i));
        }

        textView = findViewById(R.id.textView);
        textView.setText(officialList.get(0).getSearchAddress());

        mAdapter = new OfficialAdapter(officialList,this);

        recyclerView.setAdapter(mAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }


    public void setLocationResult(boolean a){
        locationResult = a;
        doAsyncGD(temp);
    }

    public void locationDialogBuild(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Can not find Location");
        builder.setMessage("Can not find such location in database. Please enter a valid city, state or zip code!");
        builder.show();
    }
}
