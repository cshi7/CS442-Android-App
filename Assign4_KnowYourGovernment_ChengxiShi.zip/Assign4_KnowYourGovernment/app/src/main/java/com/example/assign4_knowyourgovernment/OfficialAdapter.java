package com.example.assign4_knowyourgovernment;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.Date;
import java.util.List;
import java.util.Locale;

public class OfficialAdapter extends RecyclerView.Adapter<MyViewHolder>{
    private static final String TAG = "OfficialAdapter";
    private List<Officials> officialList;
    private MainActivity mainAct;

    OfficialAdapter(List<Officials> offList, MainActivity ma) {
        this.officialList = offList;
        mainAct = ma;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.officials_list, parent, false);

        itemView.setOnClickListener(mainAct);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Officials official = officialList.get(position);

        holder.title.setText(official.getOfficeName());
        holder.name.setText(official.getOfficialName());
    }

    @Override
    public int getItemCount() {
        return officialList.size();
    }
}
