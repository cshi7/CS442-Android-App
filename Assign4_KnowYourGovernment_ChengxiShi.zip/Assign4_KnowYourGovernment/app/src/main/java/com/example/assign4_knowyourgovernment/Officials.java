package com.example.assign4_knowyourgovernment;

import androidx.annotation.NonNull;

import java.util.List;

public class Officials {
    private String searchAddress; //user search which location
    private String office_name; //like president
    private String officialIndices; //ignore right now
    private String official_name; //person's name
    private String official_address; //person's government address
    private String official_party; //politic party
    private String phone; //contact phone
    private String urls; //contact website
    private String emails; //contact email box
    private String photoURL; //get photo from which website
    private String channelsList; //several social media channel


    private long offId;

    private static int ctr = 1;


    Officials(){
        this.office_name = "Official title " + ctr;
        this.official_name = "Official name " + ctr;
        this.offId = ctr;
        ctr++;
    }

    Officials(String plocation, String pOfficeName, String pOfficialIndices, String pOfficialName
    ,String pOfficialAddress, String pParty, String pPhone, String pUrls, String pEmails, String pPhotoURL, String pChannels){
        this.searchAddress = plocation;
        this.office_name = pOfficeName;
        this.officialIndices = pOfficialIndices;
        this.official_name = pOfficialName;
        this.official_address = pOfficialAddress;
        this.official_party = pParty;
        this.phone = pPhone;
        this.urls = pUrls;
        this.emails = pEmails;
        this.photoURL = pPhotoURL;
        this.channelsList = pChannels;
    }

    public String getOfficeName(){
        return office_name;
    }
    public String getOfficialName(){
        return official_name;
    }
    public String getSearchAddress(){
        return searchAddress;
    }
    public long getId(){
        return offId;
    }

    @NonNull
    @Override
    public String toString(){
        return office_name + ";" + official_name + ";" + official_party + ";"
                + photoURL + ";" + searchAddress + ";" + official_address + ";"
                + phone + ";" + urls + ";" + emails + ";" + channelsList;
    }

}
