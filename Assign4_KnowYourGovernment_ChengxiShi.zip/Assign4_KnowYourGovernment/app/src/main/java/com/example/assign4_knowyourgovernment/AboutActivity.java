package com.example.assign4_knowyourgovernment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.os.Bundle;
import android.widget.TextView;

import java.util.regex.Pattern;

public class AboutActivity extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        TextView textView = findViewById(R.id.appTitle);
        textView.setText(String.format("Know Your Government"));
        textView = findViewById(R.id.appInfo);
        textView.setText(String.format("2020, Chengxi Shi"));
        textView = findViewById(R.id.versionInfo);
        textView.setText(String.format("Version: 1.0"));

        textView = findViewById(R.id.api);
        String str_text = "<a href=https://developers.google.com/civic-information/>Google Civic Information API</a>";
        textView.setText(Html.fromHtml(str_text));
        textView.setClickable(true);
        textView.setMovementMethod(LinkMovementMethod.getInstance());;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
