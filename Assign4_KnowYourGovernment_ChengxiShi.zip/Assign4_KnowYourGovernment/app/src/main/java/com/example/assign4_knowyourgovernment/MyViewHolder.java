package com.example.assign4_knowyourgovernment;

import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

public class MyViewHolder extends RecyclerView.ViewHolder{
    public TextView name;
    TextView title;

    MyViewHolder(View view) {
        super(view);
        title = view.findViewById(R.id.official_title);
        name = view.findViewById(R.id.official_name);
    }
}
