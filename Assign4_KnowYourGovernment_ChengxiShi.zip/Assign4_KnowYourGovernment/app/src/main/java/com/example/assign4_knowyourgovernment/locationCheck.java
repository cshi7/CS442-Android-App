package com.example.assign4_knowyourgovernment;

import android.net.Uri;
import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class locationCheck extends AsyncTask<String,Void,Boolean>{

    private static final String TAG = "GoogleCivicInfoDownloader";
    private MainActivity mainActivity;
    private static final String realtimeURl = "https://www.googleapis.com/civicinfo/v2/representatives?key=AIzaSyA-lJpsQbgk56EoI1VF0gbwZjXVbJJ2YRk&address=";

    locationCheck(MainActivity ma){
        mainActivity = ma;
    }

    @Override
    protected void onPostExecute(Boolean aBoolean) {
        mainActivity.setLocationResult(aBoolean);
    }

    @Override
    protected Boolean doInBackground(String... params) {
        String locationURL = realtimeURl + params[0];

        try{
            URL url = new URL(locationURL);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.connect();

            int responseCode = connection.getResponseCode();

            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK)
                return false;

        } catch (Exception e){
            return false;
        }
        return true;
    }
}
